<?php
    //$link = mysqli_connect("localhost", "root", "root", "pets");
    $link = mysqli_connect("localhost", "mysql", "", "pets");
